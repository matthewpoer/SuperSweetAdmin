<?php
$mod_strings['LBL_SUPERSWEETADMIN_TITLE']='SuperSweetAdmin';
$mod_strings['LBL_SUPERSWEETADMIN_ENTRY_TITLE']='More System Settings';
$mod_strings['LBL_SUPERSWEETADMIN_DESC']='Configure extra system settings that the SugarCRM Interface does not normally allow access to.';
$mod_strings['LBL_PHPINFO_ENTRY_TITLE']='PHPInfo';
$mod_strings['LBL_PHPINFO_DESC']='Display server configuration from phpinfo();';
?>
