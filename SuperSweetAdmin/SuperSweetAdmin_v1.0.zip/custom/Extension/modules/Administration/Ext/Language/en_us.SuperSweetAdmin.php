<?php
$mod_strings['LBL_SUPERSWEETADMIN_TITLE']='SuperSweetAdmin';
$mod_strings['LBL_SUPERSWEETADMIN_ENTRY_TITLE']='More System Settings';
$mod_strings['LBL_SUPERSWEETADMIN_DESC']='Configure extra system settings that the SugarCRM Interface does not normally allow access to.';
?>
