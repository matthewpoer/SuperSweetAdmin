<?php
$entry_point_registry["SuperSweetAdmin"]=array("file"=>"custom/modules/Administration/supersweetadmin.php","auth"=>true);
?>